
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React, { useEffect, useRef, useState } from 'react';
import { PoxelEngine } from './services/VoxelEngine';
import { UIOverlay } from './components/UIOverlay';
import { JsonModal } from './components/JsonModal';
import { PromptModal } from './components/PromptModal';
import { WelcomeScreen } from './components/WelcomeScreen';
import { Generators } from './utils/voxelGenerators';
import { AppState, PoxelData, SavedModel } from './types';
import { GoogleGenAI, Type } from "@google/genai";

const App: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<PoxelEngine | null>(null);
  
  const [appState, setAppState] = useState<AppState>(AppState.STABLE);
  const [poxelCount, setPoxelCount] = useState<number>(0);
  const [poxelTargetCount, setPoxelTargetCount] = useState<number>(1200);
  
  const [isJsonModalOpen, setIsJsonModalOpen] = useState(false);
  const [jsonModalMode, setJsonModalMode] = useState<'view' | 'import'>('view');
  
  const [isPromptModalOpen, setIsPromptModalOpen] = useState(false);
  const [promptMode, setPromptMode] = useState<'create' | 'morph'>('create');
  
  const [showWelcome, setShowWelcome] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  
  const [jsonData, setJsonData] = useState('');
  const [isAutoRotate, setIsAutoRotate] = useState(true);
  const [performanceMode, setPerformanceMode] = useState(false);

  // --- State for Custom Models ---
  const [currentBaseModel, setCurrentBaseModel] = useState<string>('Eagle');
  const [customBuilds, setCustomBuilds] = useState<SavedModel[]>([]);
  const [customRebuilds, setCustomRebuilds] = useState<SavedModel[]>([]);

  useEffect(() => {
    if (!containerRef.current) return;

    // Initialize Engine
    const engine = new PoxelEngine(
      containerRef.current,
      (newState) => setAppState(newState),
      (count) => setPoxelCount(count)
    );

    engineRef.current = engine;
    engine.loadInitialModel(Generators.Eagle());

    const handleResize = () => engine.handleResize();
    window.addEventListener('resize', handleResize);

    const timer = setTimeout(() => setShowWelcome(false), 5000);

    return () => {
      window.removeEventListener('resize', handleResize);
      clearTimeout(timer);
      engine.cleanup();
    };
  }, []);

  const handleDismantle = () => {
    engineRef.current?.dismantle();
  };

  const handleSyncPoxelCount = () => {
    engineRef.current?.syncCount(poxelTargetCount);
  };

  const handleNewScene = (type: 'Eagle') => {
    const generator = Generators[type];
    if (generator && engineRef.current) {
      engineRef.current.loadInitialModel(generator());
      setCurrentBaseModel('Eagle');
    }
  };

  const handleSelectCustomBuild = (model: SavedModel) => {
      if (engineRef.current) {
          engineRef.current.loadInitialModel(model.data);
          setCurrentBaseModel(model.name);
      }
  };

  const handleRebuild = (type: 'Eagle' | 'Cat' | 'Rabbit' | 'Twins') => {
    const generator = Generators[type];
    if (generator && engineRef.current) {
      engineRef.current.rebuild(generator());
    }
  };

  const handleSelectCustomRebuild = (model: SavedModel) => {
      if (engineRef.current) {
          engineRef.current.rebuild(model.data);
      }
  };

  const handleShowJson = () => {
    if (engineRef.current) {
      setJsonData(engineRef.current.getJsonData());
      setJsonModalMode('view');
      setIsJsonModalOpen(true);
    }
  };

  const handleImportClick = () => {
      setJsonModalMode('import');
      setIsJsonModalOpen(true);
  };

  const handleJsonImport = (jsonStr: string) => {
      try {
          const rawData = JSON.parse(jsonStr);
          const poxelData: PoxelData[] = rawData.map((v: any) => {
              let colorVal = v.c || v.color;
              let colorInt = 0xCCCCCC;
              if (typeof colorVal === 'string') {
                  if (colorVal.startsWith('#')) colorVal = colorVal.substring(1);
                  colorInt = parseInt(colorVal, 16);
              } else if (typeof colorVal === 'number') {
                  colorInt = colorVal;
              }
              return {
                  x: Number(v.x) || 0,
                  y: Number(v.y) || 0,
                  z: Number(v.z) || 0,
                  color: isNaN(colorInt) ? 0xCCCCCC : colorInt
              };
          });
          if (engineRef.current) {
              engineRef.current.loadInitialModel(poxelData);
              setCurrentBaseModel('Imported Build');
          }
      } catch (e) {
          console.error("Failed to import JSON", e);
          alert("Failed to import JSON format.");
      }
  };

  const openPrompt = (mode: 'create' | 'morph') => {
      setPromptMode(mode);
      setIsPromptModalOpen(true);
  }
  
  const handleToggleRotation = () => {
      const newState = !isAutoRotate;
      setIsAutoRotate(newState);
      engineRef.current?.setAutoRotate(newState);
  }

  const handleTogglePerformance = () => {
    const newState = !performanceMode;
    setPerformanceMode(newState);
    engineRef.current?.setPerformanceMode(newState);
  }

  const handlePromptSubmit = async (prompt: string) => {
    if (!process.env.API_KEY) throw new Error("API Key not found");
    setIsGenerating(true);
    setIsPromptModalOpen(false);

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        // Switching to 'gemini-3-flash-preview' for maximum speed
        const model = 'gemini-3-flash-preview';
        
        const systemContext = promptMode === 'morph' ? 
            `REBUILD MODE: Fast and accurate. Convert current poxel pile into: "${prompt}". Use EXACTLY ${poxelTargetCount} poxels. High detail, vibrant colors.` : 
            `CREATE MODE: Fast masterpiece creation. Generate 3D poxel model of: "${prompt}" using ${poxelTargetCount} blocks. Maximize volume and use 30+ vibrant hex colors for shading.`;

        const response = await ai.models.generateContent({
            model,
            contents: `
                ${systemContext}
                JSON Requirements:
                - Return EXACTLY ${poxelTargetCount} unique poxels.
                - Use a wide spectrum of vibrant hex colors. No monotone.
                - Format: [{x, y, z, color: "#hex"}]
                - Coordinates centered at (0,0,0).`,
            config: {
                responseMimeType: "application/json",
                // Flash is very fast, but we can set thinkingBudget to 0 for even lower latency if needed.
                // However, some thinking helps quality. We'll leave it default for best quality-speed balance.
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            x: { type: Type.INTEGER },
                            y: { type: Type.INTEGER },
                            z: { type: Type.INTEGER },
                            color: { type: Type.STRING }
                        },
                        required: ["x", "y", "z", "color"]
                    }
                }
            }
        });

        if (response.text) {
            const rawData = JSON.parse(response.text);
            const poxelData: PoxelData[] = rawData.map((v: any) => ({
                x: v.x, y: v.y, z: v.z,
                color: parseInt(v.color.replace('#', ''), 16)
            }));

            if (engineRef.current) {
                if (promptMode === 'create') {
                    engineRef.current.loadInitialModel(poxelData);
                    setCustomBuilds(prev => [...prev, { name: prompt, data: poxelData }]);
                    setCurrentBaseModel(prompt);
                } else {
                    engineRef.current.rebuild(poxelData);
                    setCustomRebuilds(prev => [...prev, { name: prompt, data: poxelData, baseModel: currentBaseModel }]);
                }
            }
        }
    } catch (err) {
        console.error(err);
        alert("Speedy Panda error! Please try a slightly shorter prompt or retry.");
    } finally {
        setIsGenerating(false);
    }
  };

  const relevantRebuilds = customRebuilds.filter(r => r.baseModel === currentBaseModel);

  return (
    <div className="relative w-full h-screen bg-[#f0f2f5] overflow-hidden">
      <div ref={containerRef} className="absolute inset-0 z-0" />
      
      <UIOverlay 
        poxelCount={poxelCount}
        poxelTargetCount={poxelTargetCount}
        setPoxelTargetCount={setPoxelTargetCount}
        onSyncPoxels={handleSyncPoxelCount}
        appState={appState}
        currentBaseModel={currentBaseModel}
        customBuilds={customBuilds}
        customRebuilds={relevantRebuilds} 
        isAutoRotate={isAutoRotate}
        isInfoVisible={showWelcome}
        isGenerating={isGenerating}
        performanceMode={performanceMode}
        onDismantle={handleDismantle}
        onRebuild={handleRebuild}
        onNewScene={handleNewScene}
        onSelectCustomBuild={handleSelectCustomBuild}
        onSelectCustomRebuild={handleSelectCustomRebuild}
        onPromptCreate={() => openPrompt('create')}
        onPromptMorph={() => openPrompt('morph')}
        onShowJson={handleShowJson}
        onImportJson={handleImportClick}
        onToggleRotation={handleToggleRotation}
        onToggleInfo={() => setShowWelcome(!showWelcome)}
        onTogglePerformance={handleTogglePerformance}
      />

      <WelcomeScreen visible={showWelcome} />
      <JsonModal isOpen={isJsonModalOpen} onClose={() => setIsJsonModalOpen(false)} data={jsonData} isImport={jsonModalMode === 'import'} onImport={handleJsonImport} />
      <PromptModal isOpen={isPromptModalOpen} mode={promptMode} onClose={() => setIsPromptModalOpen(false)} onSubmit={handlePromptSubmit} />
    </div>
  );
};

export default App;
