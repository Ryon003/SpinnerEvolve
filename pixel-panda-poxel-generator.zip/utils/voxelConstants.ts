
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

export const COLORS = {
  // Naturals & Bases
  DARK: 0x4A3728,
  LIGHT: 0x654321,
  WHITE: 0xF0F0F0,
  GOLD: 0xFFD700,
  BLACK: 0x111111,
  WOOD: 0x3B2F2F,
  GREEN: 0x228B22,
  TALON: 0xE5C100,
  
  // Vivids & Accents
  SKY_BLUE: 0x0ea5e9,
  ROSE: 0xf43f5e,
  VIOLET: 0x8b5cf6,
  AMBER: 0xf59e0b,
  EMERALD: 0x10b981,
  CRIMSON: 0x991b1b,
  NEON_GREEN: 0x4ade80,
  PANDA_WHITE: 0xffffff,
  PANDA_BLACK: 0x171717,
  
  // New Palettes (Pastels & Deep)
  MINT: 0xa7f3d0,
  LAVENDER: 0xe9d5ff,
  PEACH: 0xffedd5,
  CYAN: 0x22d3ee,
  INDIGO_DEEP: 0x312e81,
  SLATE_STEEL: 0x475569,
  SUNSET_ORANGE: 0xf97316,
  LIME_VIBE: 0x84cc16,
  HOT_PINK: 0xdb2777,
  DEEP_TEAL: 0x0f766e
};

export const CONFIG = {
  POXEL_SIZE: 1,
  FLOOR_Y: -12,
  BG_COLOR: 0xf0f2f5,
  MAX_POXELS_DEFAULT: 2500, 
};
